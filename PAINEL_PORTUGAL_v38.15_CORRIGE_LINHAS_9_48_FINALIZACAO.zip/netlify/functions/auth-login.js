const { jsonResponse, createSessionCookie, normalizeText } = require('./_auth');

function normalizeOperationRegion(value = 'PT') {
  // Build Portugal: site separado do Brasil. Nunca autentica como BR.
  return 'PT';
}

function getLoginRegion(event, body = {}) {
  return 'PT';
}

const { getUserByUsername, isSupabaseConfigured, userPasswordMatches, upsertUserPresence } = require('./_supabase');


function getClientIp(event) {
  const headers = event?.headers || {};
  return String(headers['x-forwarded-for'] || headers['X-Forwarded-For'] || headers['client-ip'] || '')
    .split(',')[0]
    .trim();
}

function getUserAgent(event) {
  const headers = event?.headers || {};
  return String(headers['user-agent'] || headers['User-Agent'] || '').trim();
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return jsonResponse(405, { ok: false, error: 'Método não permitido.' });
  }

  try {
    if (!isSupabaseConfigured()) {
      return jsonResponse(500, { ok: false, error: 'Supabase não configurado no Netlify.' });
    }
    const body = JSON.parse(event.body || '{}');
    const username = String(body.username || '').trim();
    const password = String(body.password || '').trim();
    if (!username || !password) {
      return jsonResponse(400, { ok: false, error: 'Informe usuário e senha.' });
    }

    const operationRegion = getLoginRegion(event, body);
    const user = await getUserByUsername(username, { operationRegion });

    if (!user || !user.active || !userPasswordMatches(password, user.passwordHash)) {
      return jsonResponse(401, { ok: false, error: 'Usuário ou senha inválidos.' });
    }

    // Otimização: presença não bloqueia o login.
    Promise.resolve().then(() => upsertUserPresence({
      userId: user.id,
      username: user.username,
      name: user.name,
      role: user.role,
      sector: user.sector,
      alertSectors: Array.isArray(user.alertSectors) ? user.alertSectors : [],
      status: 'online',
      markLogin: true,
      lastViewName: 'Login no sistema',
      lastViewUrl: '/',
      lastViewTitle: 'STEP - Painel Operacional',
      userAgent: getUserAgent(event),
      ipAddress: getClientIp(event),
    })).catch(() => null);

    return jsonResponse(200, {
      ok: true,
      user: {
        id: user.id,
        name: user.name,
        username: user.username,
        role: user.role,
        sector: user.sector,
        alertSectors: Array.isArray(user.alertSectors) ? user.alertSectors : [],
        projectPmAliases: Array.isArray(user.projectPmAliases) ? user.projectPmAliases : [],
        qualityCompetencies: Array.isArray(user.qualityCompetencies) ? user.qualityCompetencies : [],
        canViewClientPanel: user.canViewClientPanel === true,
        clientKey: user.clientKey || '',
        operationRegion: user.operationRegion || 'PT',
        siteKey: user.siteKey || user.operationRegion || 'PT',
        clientName: user.clientName || '',
        clientLogoUrl: user.clientLogoUrl || '',
        clientPlatformImageUrl: user.clientPlatformImageUrl || '',
        clientPlatformImages: user.clientPlatformImages || {},
        allowedClients: Array.isArray(user.allowedClients) ? user.allowedClients : [],
      },
    }, {
      headers: {
        'set-cookie': createSessionCookie(user),
      },
    });
  } catch (error) {
    return jsonResponse(500, { ok: false, error: error.message || 'Falha ao autenticar.' });
  }
};
